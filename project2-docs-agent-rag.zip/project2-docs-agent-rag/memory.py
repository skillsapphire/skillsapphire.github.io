"""
memory.py — Lightweight seen-docs memory. Tracks which chunks have
already been surfaced in a session so a follow-up question doesn't
re-retrieve (and re-pay for) the same context.
"""
from collections import defaultdict


class SeenDocsMemory:
    def __init__(self):
        self._seen: dict[str, set[str]] = defaultdict(set)

    def filter_unseen(self, session_id: str, hits: list[dict]) -> list[dict]:
        seen = self._seen[session_id]
        unseen = [h for h in hits if h["source"] not in seen]
        # If everything was already seen, fall back to the top hit anyway —
        # better to re-cite than to answer with nothing.
        return unseen or hits[:1]

    def mark_seen(self, session_id: str, hits: list[dict]) -> None:
        for h in hits:
            self._seen[session_id].add(h["source"])

    def summary(self, session_id: str) -> str:
        seen = self._seen[session_id]
        if not seen:
            return "none yet"
        return f"{len(seen)} source(s) already surfaced: " + ", ".join(sorted(seen))
