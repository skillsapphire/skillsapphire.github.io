# Refund Policy

Annual plans cancelled mid-term are refunded on a pro-rated basis for
any full unused months remaining in the current billing cycle. Partial
months are not refunded.

Monthly plans are non-refundable after the initial 7-day trial window.
Cancelling a monthly plan stops future billing but does not refund the
current billing period.

Refunds are issued to the original payment method within 5-10 business
days. Invoice-paid accounts receive refunds as account credit rather
than a payment reversal, since there is no card to refund to.
