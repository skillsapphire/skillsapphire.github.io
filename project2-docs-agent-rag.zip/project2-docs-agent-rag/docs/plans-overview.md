# Plans Overview

We offer three plan tiers: Starter, Growth, and Enterprise. Starter and
Growth are self-serve and billed monthly or annually by card. Enterprise
plans are billed annually via invoice and include a dedicated account
manager.

Annual plans receive a 15% discount versus paying monthly, and lock in
the price for the full contract term regardless of later list price
changes.

Downgrading a plan takes effect at the start of the next billing cycle.
Upgrading takes effect immediately, with a prorated charge for the
remainder of the current cycle.
