# SSO Setup (SAML with Okta)

1. In the admin console, go to Settings > Security > SSO and select SAML.
2. Copy the ACS URL and Entity ID shown on that page.
3. In Okta, create a new SAML 2.0 application and paste the ACS URL and
   Entity ID into the corresponding fields.
4. Map the "email" and "name" attributes from Okta to the matching
   fields in the admin console SSO form.
5. Download the Okta SAML metadata XML and upload it back into the
   admin console SSO form, then click Verify.
6. Assign users to the Okta application to grant them SSO access; users
   not assigned in Okta cannot sign in via SSO.

Rate limits: the bulk export endpoint allows 10 requests per minute per
account, returning HTTP 429 with a Retry-After header if exceeded.
