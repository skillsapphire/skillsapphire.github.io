# Invoicing (Enterprise)

Enterprise accounts are billed annually via invoice with net-30 payment
terms. Invoices are issued 30 days before the renewal date.

Invoice-paid accounts follow the same pro-ration rules as card-paid
accounts for refunds and mid-term changes, but any refund is issued as
account credit rather than a bank transfer, and applied to the next
invoice.

To change the billing contact or purchase order number on an invoice,
contact your account manager at least 5 business days before the
invoice is issued.
