"""
eval_harness.py — Replays the golden Q&A set through the live agent and
scores each answer for faithfulness and relevance with an LLM judge.

Run standalone:
    python eval_harness.py

Run as a CI gate:
    pytest tests/test_eval.py -v
"""
import json
import os
import statistics

from anthropic import Anthropic
from dotenv import load_dotenv

from retrieval_agent import answer

load_dotenv()

MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5")
client = Anthropic()

GOLDEN_SET_PATH = os.path.join(os.path.dirname(__file__), "eval", "golden_set.json")
FAITHFULNESS_THRESHOLD = 0.7
RELEVANCE_THRESHOLD = 0.7

JUDGE_PROMPT = """Score the ANSWER against the SOURCE CONTEXT and the QUESTION.
Respond with ONLY strict JSON, no other text:
{{"faithfulness": <0-1 float>, "relevance": <0-1 float>, "reason": "<short reason>"}}

faithfulness = is every claim in the answer supported by the context?
relevance = does the answer actually address the question asked?

QUESTION: {question}
CONTEXT: {context}
ANSWER: {answer}"""


def judge(question: str, context: str, answer_text: str) -> dict:
    resp = client.messages.create(
        model=MODEL,
        max_tokens=250,
        messages=[
            {
                "role": "user",
                "content": JUDGE_PROMPT.format(
                    question=question, context=context, answer=answer_text
                ),
            }
        ],
    )
    raw = resp.content[0].text.strip()
    # Strip accidental markdown fences if the model adds them
    raw = raw.removeprefix("```json").removeprefix("```").removesuffix("```").strip()
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {"faithfulness": 0.0, "relevance": 0.0, "reason": f"unparseable judge output: {raw[:120]}"}


def run_regression() -> dict:
    golden_set = json.load(open(GOLDEN_SET_PATH))
    results = []
    for case in golden_set:
        response_text = answer(case["question"], session_id=f"eval-{case['id']}")
        scores = judge(case["question"], case["expected_context"], response_text)
        passed = (
            scores.get("faithfulness", 0) >= FAITHFULNESS_THRESHOLD
            and scores.get("relevance", 0) >= RELEVANCE_THRESHOLD
        )
        results.append({"id": case["id"], "passed": passed, "answer": response_text, **scores})

    pass_rate = sum(r["passed"] for r in results) / len(results)
    avg_faith = statistics.mean(r.get("faithfulness", 0) for r in results)
    return {"pass_rate": pass_rate, "avg_faithfulness": avg_faith, "cases": results}


if __name__ == "__main__":
    report = run_regression()
    print(f"\nPass rate: {report['pass_rate']:.0%}  |  Avg faithfulness: {report['avg_faithfulness']:.2f}\n")
    for c in report["cases"]:
        status = "PASS" if c["passed"] else "FAIL"
        print(f"[{status}] {c['id']}  faith={c.get('faithfulness'):.2f}  rel={c.get('relevance'):.2f}  {c.get('reason','')}")
