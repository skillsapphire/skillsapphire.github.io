"""
retrieval_agent.py — Agentic RAG: retrieval is exposed as a tool, not a
hardcoded pre-step. The agent reads the question and its own seen-docs
memory, then decides whether retrieval is needed at all.
"""
import json
import os

import chromadb
from anthropic import Anthropic
from chromadb.utils import embedding_functions
from dotenv import load_dotenv

from memory import SeenDocsMemory

load_dotenv()

MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5")

client = Anthropic()
_chroma = chromadb.PersistentClient(path="./vector_store")
_embed_fn = embedding_functions.DefaultEmbeddingFunction()
store = _chroma.get_or_create_collection("docs", embedding_function=_embed_fn)
memory = SeenDocsMemory()

SYSTEM = """You are a support docs agent. You have a retrieve_docs tool over \
the product documentation. Only call it when the question needs specific \
facts you don't already have from earlier in this session — for general \
or already-answered questions, answer directly. Always cite sources by \
file name in square brackets when you use retrieved text, e.g. [refunds.md]."""

RETRIEVE_TOOL = {
    "name": "retrieve_docs",
    "description": "Search the product documentation for relevant passages.",
    "input_schema": {
        "type": "object",
        "properties": {
            "query": {"type": "string"},
            "top_k": {"type": "integer", "default": 4},
        },
        "required": ["query"],
    },
}


def retrieve_docs(query: str, top_k: int = 4, session_id: str = "default") -> list[dict]:
    if store.count() == 0:
        return [{"text": "(no documents ingested yet — run `python ingest.py` first)",
                  "source": "system", "score": 0.0}]

    results = store.query(query_texts=[query], n_results=min(top_k, store.count()))
    hits = [
        {"text": doc, "source": meta["source"], "score": round(1 - dist, 3)}
        for doc, meta, dist in zip(
            results["documents"][0], results["metadatas"][0], results["distances"][0]
        )
    ]
    fresh = memory.filter_unseen(session_id, hits)
    memory.mark_seen(session_id, fresh)
    return fresh


def answer(question: str, session_id: str = "default") -> str:
    messages = [{"role": "user", "content": question}]

    response = client.messages.create(
        model=MODEL,
        max_tokens=800,
        system=[
            {"type": "text", "text": SYSTEM, "cache_control": {"type": "ephemeral"}}
        ],
        tools=[RETRIEVE_TOOL],
        messages=messages,
    )

    for _ in range(2):
        tool_uses = [b for b in response.content if b.type == "tool_use"]
        if not tool_uses:
            break

        messages.append({"role": "assistant", "content": response.content})
        tool_results = []
        for block in tool_uses:
            hits = retrieve_docs(session_id=session_id, **block.input)
            tool_results.append(
                {"type": "tool_result", "tool_use_id": block.id, "content": json.dumps(hits)}
            )
        messages.append({"role": "user", "content": tool_results})

        response = client.messages.create(
            model=MODEL,
            max_tokens=800,
            system=[
                {"type": "text", "text": SYSTEM, "cache_control": {"type": "ephemeral"}}
            ],
            tools=[RETRIEVE_TOOL],
            messages=messages,
        )

    return "\n".join(b.text for b in response.content if b.type == "text")
