"""
run_demo.py — CLI entry point.

Usage:
    python run_demo.py "your question here"
    python run_demo.py "your question here" --session my-session
"""
import sys
import uuid

from retrieval_agent import answer

if __name__ == "__main__":
    args = sys.argv[1:]
    session_id = str(uuid.uuid4())[:8]
    if "--session" in args:
        idx = args.index("--session")
        session_id = args[idx + 1]
        args = args[:idx] + args[idx + 2 :]

    question = " ".join(args) or "What's our refund policy for annual plans cancelled mid-term?"

    print(f"\nSession: {session_id}")
    print(f"Question: {question}\n")

    result = answer(question, session_id=session_id)

    print("=== ANSWER ===\n")
    print(result)
    print(f"\n(Reuse --session {session_id} to ask a follow-up and exercise seen-docs memory.)")
