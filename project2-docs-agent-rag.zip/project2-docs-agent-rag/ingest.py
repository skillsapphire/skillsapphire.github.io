"""
ingest.py — Chunks the markdown files in docs/ and writes embeddings to
a local, persistent Chroma collection. Run whenever the doc set changes:

    python ingest.py
    python ingest.py ./docs      (custom folder)

Note: the first run downloads a small embedding model via chromadb's
default embedding function (needs internet once; cached afterward).
"""
import hashlib
import sys
from pathlib import Path

import chromadb
from chromadb.utils import embedding_functions

CHUNK_SIZE = 512
CHUNK_OVERLAP = 64


def get_collection():
    client = chromadb.PersistentClient(path="./vector_store")
    embed_fn = embedding_functions.DefaultEmbeddingFunction()
    return client.get_or_create_collection("docs", embedding_function=embed_fn)


def chunk_text(text: str, source: str) -> list[dict]:
    paragraphs = [p for p in text.split("\n\n") if p.strip()]
    chunks, buf = [], ""
    for para in paragraphs:
        if len(buf) + len(para) > CHUNK_SIZE and buf:
            chunks.append(buf.strip())
            buf = buf[-CHUNK_OVERLAP:]
        buf += "\n\n" + para
    if buf.strip():
        chunks.append(buf.strip())
    return [{"text": c, "source": source} for c in chunks]


def ingest_directory(path: str) -> None:
    collection = get_collection()
    count = 0
    for file in Path(path).rglob("*.md"):
        text = file.read_text(encoding="utf-8")
        for chunk in chunk_text(text, source=file.name):
            cid = hashlib.sha256(chunk["text"].encode()).hexdigest()[:16]
            collection.upsert(
                ids=[cid],
                documents=[chunk["text"]],
                metadatas=[{"source": chunk["source"]}],
            )
            count += 1
    print(f"Ingested {count} chunk(s) from '{path}'. Collection now has "
          f"{collection.count()} chunks total.")


if __name__ == "__main__":
    ingest_directory(sys.argv[1] if len(sys.argv) > 1 else "./docs")
