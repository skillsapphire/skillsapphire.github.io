# Project 2 — Docs Agent (Agentic RAG + Eval Harness)

A support-docs agent where retrieval is a tool the agent chooses to
call, not a hardcoded pre-step, plus an eval harness that replays a
golden Q&A set through the live agent and scores it with an LLM judge.

## File structure

```
project2-docs-agent-rag/
├── ingest.py               # Chunk + embed docs/ into a local Chroma collection
├── retrieval_agent.py        # Agentic RAG: retrieval exposed as a tool
├── memory.py                  # Seen-docs session memory
├── eval_harness.py             # Golden-set regression + LLM-as-judge scoring
├── run_demo.py                  # CLI entry point
├── docs/
│   ├── refunds.md
│   ├── plans-overview.md
│   ├── invoicing.md
│   └── sso-setup.md
├── eval/
│   └── golden_set.json           # 6 sample Q&A pairs (scale this up for real use)
├── tests/
│   └── test_eval.py               # pytest gate, skips if no API key set
├── requirements.txt
├── .env.example
└── README.md
(vector_store/ is created automatically by ingest.py)
```

## Setup on Windows

1. **Install Python 3.11+** from [python.org](https://www.python.org/downloads/) if needed (check "Add python.exe to PATH" during install).

2. **Open PowerShell or Command Prompt** in this folder.

3. **Create and activate a virtual environment:**
   ```powershell
   python -m venv .venv
   .venv\Scripts\activate
   ```
   (If PowerShell blocks the script: `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`, then retry.)

4. **Install dependencies:**
   ```powershell
   pip install -r requirements.txt
   ```
   `chromadb` pulls in a few sub-dependencies; this step can take a couple of minutes the first time.

5. **Add your API key:**
   ```powershell
   copy .env.example .env
   ```
   Edit `.env` in Notepad and paste your key from [console.anthropic.com](https://console.anthropic.com/).

6. **Ingest the sample docs** (builds the local vector store — needs internet once, to download the small embedding model):
   ```powershell
   python ingest.py
   ```

7. **Ask a question:**
   ```powershell
   python run_demo.py "What's our refund policy for annual plans cancelled mid-term?"
   ```

8. **Ask a follow-up in the same session** (exercises seen-docs memory):
   ```powershell
   python run_demo.py "What about accounts paid via invoice?" --session abc123
   ```
   (use the session id printed at the end of step 7)

9. **Run the eval harness** (replays the golden set and scores each answer):
   ```powershell
   python eval_harness.py
   ```
   or as a pytest gate:
   ```powershell
   pytest tests/test_eval.py -v
   ```

## Notes

- Re-run `python ingest.py` any time you add or edit files in `docs/`.
- The golden set has 6 pairs for a fast demo; a real deployment would grow this to 40+ and run it in CI on every prompt or chunking change.
- Swap the model by setting `ANTHROPIC_MODEL` in `.env` (defaults to `claude-sonnet-5`).
- `vector_store/` is created in this folder — delete it to reset and re-ingest from scratch.
