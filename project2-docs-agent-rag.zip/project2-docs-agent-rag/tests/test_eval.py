"""
tests/test_eval.py — Runs the golden-set regression as a pytest gate.
Skips automatically if ANTHROPIC_API_KEY isn't set (e.g. in an
environment where you just want to check imports/structure).

Run:
    pytest tests/test_eval.py -v
"""
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

requires_api_key = pytest.mark.skipif(
    not os.environ.get("ANTHROPIC_API_KEY"),
    reason="ANTHROPIC_API_KEY not set — skipping live eval run",
)


@requires_api_key
def test_regression_gate():
    from eval_harness import run_regression

    report = run_regression()
    assert report["pass_rate"] >= 0.60, (
        f"Eval pass rate dropped to {report['pass_rate']:.0%} "
        f"(cases: {[c['id'] for c in report['cases'] if not c['passed']]})"
    )
