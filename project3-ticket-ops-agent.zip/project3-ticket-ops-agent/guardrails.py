"""
guardrails.py — Two independent checks before anything reaches a human:
a JSON-schema validation of the proposal shape, and a hard allowlist of
permitted actions with policy limits (e.g. max refund amount).
"""
from dataclasses import dataclass

from jsonschema import ValidationError, validate

ALLOWED_ACTIONS = {"issue_refund", "escalate", "reply_only"}
MAX_REFUND_USD = 250.0
MAX_REFUND_REQUIRING_SECOND_APPROVER = 250.0

PROPOSAL_SCHEMA = {
    "type": "object",
    "properties": {
        "action": {"type": "string"},
        "amount_usd": {"type": "number"},
        "reason": {"type": "string", "minLength": 5},
    },
    "required": ["action", "reason"],
}


@dataclass
class GuardrailResult:
    passed: bool
    reason: str = ""
    requires_second_approver: bool = False


def validate_proposal(proposal: dict) -> GuardrailResult:
    try:
        validate(proposal, PROPOSAL_SCHEMA)
    except ValidationError as e:
        return GuardrailResult(passed=False, reason=f"schema: {e.message}")

    if proposal["action"] not in ALLOWED_ACTIONS:
        return GuardrailResult(passed=False, reason=f"'{proposal['action']}' not in allowlist")

    if proposal["action"] == "issue_refund":
        amount = proposal.get("amount_usd", 0)
        if amount > MAX_REFUND_USD:
            return GuardrailResult(
                passed=False,
                reason=f"${amount} exceeds ${MAX_REFUND_USD} auto-propose limit",
            )
        return GuardrailResult(
            passed=True,
            requires_second_approver=amount >= MAX_REFUND_REQUIRING_SECOND_APPROVER,
        )

    return GuardrailResult(passed=True)
