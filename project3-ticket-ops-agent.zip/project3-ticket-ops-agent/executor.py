"""
executor.py — The only component with real side effects. This demo
appends to a local JSON ledger instead of calling real billing/CRM
APIs, but the call signature matches what a production executor would use.
"""
import json
import time
from pathlib import Path

from observability import traced_span

LEDGER_PATH = Path("action_ledger.json")


@traced_span("executor.run")
def run(proposal: dict, approved_by: str) -> str:
    entry = {
        "timestamp": time.time(),
        "action": proposal["action"],
        "amount_usd": proposal.get("amount_usd"),
        "reason": proposal["reason"],
        "approved_by": approved_by,
    }
    ledger = json.loads(LEDGER_PATH.read_text()) if LEDGER_PATH.exists() else []
    ledger.append(entry)
    LEDGER_PATH.write_text(json.dumps(ledger, indent=2))
    return f"Executed '{proposal['action']}' (approved by {approved_by}) — logged to {LEDGER_PATH}"
