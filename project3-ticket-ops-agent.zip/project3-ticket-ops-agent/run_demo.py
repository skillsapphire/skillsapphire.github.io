"""
run_demo.py — Interactive CLI.

Usage:
    python run_demo.py
"""
from workflow_agent import handle_ticket

if __name__ == "__main__":
    print("Ticket Ops Agent — paste a ticket description and press Enter.")
    print("(Ctrl+C to quit)\n")
    print("Try: 'Customer was double-charged $89.00 for their October invoice, requesting a refund.'\n")

    while True:
        try:
            ticket = input("Ticket: ").strip()
            if not ticket:
                continue
            result = handle_ticket(ticket)
            print(f"\n{result}\n")
        except KeyboardInterrupt:
            print("\nExiting.")
            break
