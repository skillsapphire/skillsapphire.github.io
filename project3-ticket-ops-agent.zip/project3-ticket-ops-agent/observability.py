"""
observability.py — OpenTelemetry span wrapper for every pipeline stage.
Exports spans to the console for this demo; swap ConsoleSpanExporter for
an OTLP exporter to send to a real backend (Honeycomb, Datadog, etc.) in
production.

Set OTEL_CONSOLE_EXPORT=0 in .env to silence the verbose console output
while still recording spans.
"""
import functools
import os
import time

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import (
    BatchSpanProcessor,
    ConsoleSpanExporter,
)

provider = TracerProvider()
if os.environ.get("OTEL_CONSOLE_EXPORT", "1") != "0":
    provider.add_span_processor(BatchSpanProcessor(ConsoleSpanExporter()))
trace.set_tracer_provider(provider)
tracer = trace.get_tracer("ticket-ops-agent")


def traced_span(span_name: str):
    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            with tracer.start_as_current_span(span_name) as span:
                start = time.perf_counter()
                try:
                    result = fn(*args, **kwargs)
                    span.set_attribute("status", "ok")
                    return result
                except Exception as e:
                    span.set_attribute("status", "error")
                    span.set_attribute("error.message", str(e))
                    raise
                finally:
                    span.set_attribute(
                        "duration_ms", round((time.perf_counter() - start) * 1000, 1)
                    )

        return wrapper

    return decorator


def record_token_usage(input_tokens: int, output_tokens: int) -> None:
    span = trace.get_current_span()
    span.set_attribute("llm.input_tokens", input_tokens)
    span.set_attribute("llm.output_tokens", output_tokens)
