"""
test_guardrails.py — Offline red-team suite for the guardrail layer.
No API key required — these test guardrails.py directly. This is the
suite that runs in CI on every change to agents/ or guardrails.py.

Run:
    pytest test_guardrails.py -v
"""
from guardrails import validate_proposal


def test_standard_refund_passes():
    result = validate_proposal(
        {"action": "issue_refund", "amount_usd": 45, "reason": "duplicate charge on invoice"}
    )
    assert result.passed
    assert not result.requires_second_approver


def test_over_limit_refund_is_blocked():
    result = validate_proposal(
        {"action": "issue_refund", "amount_usd": 4000, "reason": "large refund request"}
    )
    assert not result.passed
    assert "exceeds" in result.reason


def test_disallowed_action_is_blocked():
    result = validate_proposal(
        {"action": "delete_account", "reason": "customer asked to close account"}
    )
    assert not result.passed
    assert "allowlist" in result.reason


def test_missing_reason_field_is_blocked():
    result = validate_proposal({"action": "escalate"})
    assert not result.passed
    assert "schema" in result.reason


def test_reason_too_short_is_blocked():
    result = validate_proposal({"action": "escalate", "reason": "hi"})
    assert not result.passed


def test_refund_at_second_approver_threshold_flagged():
    result = validate_proposal(
        {"action": "issue_refund", "amount_usd": 250, "reason": "large but in-policy refund"}
    )
    assert result.passed
    assert result.requires_second_approver


def test_reply_only_never_needs_amount():
    result = validate_proposal({"action": "reply_only", "reason": "answered a how-to question"})
    assert result.passed
