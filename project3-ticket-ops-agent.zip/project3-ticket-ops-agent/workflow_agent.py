"""
workflow_agent.py — Triages a ticket and calls propose_action, a tool
that returns a structured proposal. The agent has no tool capable of
actually changing anything — that boundary is deliberate.
"""
import os

from anthropic import Anthropic
from dotenv import load_dotenv

import executor
from approval_gate import request_approval
from guardrails import validate_proposal
from observability import traced_span

load_dotenv()

MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5")
client = Anthropic()

SYSTEM = """You triage support tickets and propose exactly one action using the \
propose_action tool: issue_refund, escalate, or reply_only. Never claim an \
action has happened — you can only propose it. Keep proposed refund amounts \
reasonable and tied to what the ticket actually describes."""

PROPOSE_ACTION_TOOL = {
    "name": "propose_action",
    "description": "Propose one action for a human to review. Does not execute anything.",
    "input_schema": {
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["issue_refund", "escalate", "reply_only"]},
            "amount_usd": {"type": "number"},
            "reason": {"type": "string"},
        },
        "required": ["action", "reason"],
    },
}


@traced_span("agent.triage")
def triage(ticket_text: str) -> dict:
    response = client.messages.create(
        model=MODEL,
        max_tokens=500,
        system=[
            {"type": "text", "text": SYSTEM, "cache_control": {"type": "ephemeral"}}
        ],
        tools=[PROPOSE_ACTION_TOOL],
        tool_choice={"type": "tool", "name": "propose_action"},
        messages=[{"role": "user", "content": ticket_text}],
    )
    proposal = next(b.input for b in response.content if b.type == "tool_use")
    return proposal


def handle_ticket(ticket_text: str) -> str:
    proposal = triage(ticket_text)

    check = validate_proposal(proposal)
    if not check.passed:
        return f"Blocked by guardrail: {check.reason}"

    decision = request_approval(proposal)
    if not decision.approved:
        return f"Rejected by {decision.approver}: {decision.note}"

    return executor.run(proposal, approved_by=decision.approver)
