# Project 3 — Ticket Ops Agent (Guardrails, Approvals, Observability)

A ticket-triage agent that proposes an action but never executes one
directly. Every proposal passes a schema + allowlist guardrail, then
waits for human approval, before an executor with real side effects
runs. Every stage emits an OpenTelemetry trace span.

## File structure

```
project3-ticket-ops-agent/
├── workflow_agent.py         # Triages a ticket, proposes an action (propose-only)
├── guardrails.py               # Schema validation + hard action allowlist
├── approval_gate.py             # Human-in-the-loop approval (CLI stand-in for Slack)
├── executor.py                   # The only component with real side effects
├── observability.py               # OpenTelemetry span decorator
├── run_demo.py                     # Interactive CLI
├── test_guardrails.py                # Offline red-team suite, no API key needed
├── .github/workflows/ci.yml           # Guardrail suite gating every PR
├── requirements.txt
├── .env.example
└── README.md
(action_ledger.json is created automatically once you approve an action)
```

## Setup on Windows

1. **Install Python 3.11+** from [python.org](https://www.python.org/downloads/) if needed (check "Add python.exe to PATH" during install).

2. **Open PowerShell or Command Prompt** in this folder.

3. **Create and activate a virtual environment:**
   ```powershell
   python -m venv .venv
   .venv\Scripts\activate
   ```
   (If PowerShell blocks the script: `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`, then retry.)

4. **Install dependencies:**
   ```powershell
   pip install -r requirements.txt
   ```

5. **Add your API key:**
   ```powershell
   copy .env.example .env
   ```
   Edit `.env` in Notepad and paste your key from [console.anthropic.com](https://console.anthropic.com/).

6. **Run the offline guardrail suite first** (no API key needed — good first check):
   ```powershell
   pytest test_guardrails.py -v
   ```

7. **Run the interactive demo** (this calls the Anthropic API):
   ```powershell
   python run_demo.py
   ```
   Paste a ticket like:
   ```
   Customer was double-charged $89.00 for their October invoice, requesting a refund.
   ```
   You'll see the agent's proposal, the guardrail check, and a `y`/`N` prompt before anything executes.

8. **Check what got executed:**
   ```powershell
   type action_ledger.json
   ```

## Notes

- `observability.py` prints a JSON span to the console on every stage by default — set `OTEL_CONSOLE_EXPORT=0` in `.env` to quiet it while still recording spans.
- The `approval_gate.py` CLI prompt stands in for a real Slack approve/reject button in a deployed version — same contract either way.
- Swap the model by setting `ANTHROPIC_MODEL` in `.env` (defaults to `claude-sonnet-5`).
- `action_ledger.json` is created in this folder the first time you approve an action — delete it to reset.
