"""
approval_gate.py — Every guardrail-passed proposal still blocks on a
human decision. This CLI version stands in for the real Slack approval
flow used in a deployed pipeline: same contract either way — nothing
downstream runs until an ApprovalDecision comes back.
"""
from dataclasses import dataclass

from observability import traced_span


@dataclass
class ApprovalDecision:
    approved: bool
    approver: str
    note: str = ""


@traced_span("approval.request")
def request_approval(proposal: dict) -> ApprovalDecision:
    print(f"\nProposal: {proposal}")
    reply = input("Approve? [y/N]: ").strip().lower()

    if reply == "y":
        return ApprovalDecision(approved=True, approver="cli-operator")
    return ApprovalDecision(approved=False, approver="cli-operator", note="declined at approval gate")
