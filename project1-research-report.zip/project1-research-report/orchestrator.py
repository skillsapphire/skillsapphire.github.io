"""
orchestrator.py — Wires the four agents into a stateful graph and owns
the run loop, including session memory persistence.
"""
from typing import TypedDict

from langgraph.graph import END, StateGraph

from agents import analyst_turn, plan_subtasks, researcher_turn, writer_turn
from memory import SessionMemory


class PipelineState(TypedDict):
    query: str
    subtasks: list[str]
    findings: list[str]
    analysis: str
    report: str
    memory_summary: str


memory = SessionMemory(store_path="sessions.db")


def orchestrate(state: PipelineState) -> PipelineState:
    state["subtasks"] = plan_subtasks(state["query"], state["memory_summary"])
    return state


def research(state: PipelineState) -> PipelineState:
    state["findings"] = [
        researcher_turn(q, state["memory_summary"]) for q in state["subtasks"]
    ]
    return state


def analyze(state: PipelineState) -> PipelineState:
    state["analysis"] = analyst_turn(state["findings"])
    return state


def write(state: PipelineState) -> PipelineState:
    state["report"] = writer_turn(state["analysis"], state["query"])
    return state


graph = StateGraph(PipelineState)
graph.add_node("orchestrate", orchestrate)
graph.add_node("research", research)
graph.add_node("analyze", analyze)
graph.add_node("write", write)
graph.set_entry_point("orchestrate")
graph.add_edge("orchestrate", "research")
graph.add_edge("research", "analyze")
graph.add_edge("analyze", "write")
graph.add_edge("write", END)

pipeline = graph.compile()


def run(query: str, session_id: str) -> str:
    prior = memory.load_summary(session_id)
    result = pipeline.invoke(
        {
            "query": query,
            "memory_summary": prior,
            "subtasks": [],
            "findings": [],
            "analysis": "",
            "report": "",
        }
    )
    memory.save_turn(session_id, query, result["report"])
    return result["report"]
