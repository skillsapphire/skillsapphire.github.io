"""
mcp_client.py — Thin synchronous wrapper around the official MCP Python
SDK so the rest of the codebase can call MCP tools without dealing with
asyncio directly. Spawns mcp_server.py as a subprocess over stdio.
"""
import asyncio
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


class MCPToolClient:
    def __init__(self, server_command: list[str]):
        # Use the same python interpreter that's running this process,
        # so it works inside a venv on Windows without a PATH lookup.
        command = server_command[0]
        if command in ("python", "python3"):
            command = sys.executable
        self._server_params = StdioServerParameters(
            command=command, args=server_command[1:]
        )
        self._tools_cache: list[dict] | None = None

    async def _list_tools_async(self):
        async with stdio_client(self._server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.list_tools()
                return result.tools

    async def _call_tool_async(self, name: str, arguments: dict):
        async with stdio_client(self._server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.call_tool(name, arguments)
                return "\n".join(
                    block.text for block in result.content if hasattr(block, "text")
                )

    def as_anthropic_tools(self) -> list[dict]:
        if self._tools_cache is None:
            tools = asyncio.run(self._list_tools_async())
            self._tools_cache = [
                {
                    "name": t.name,
                    "description": t.description or "",
                    "input_schema": t.inputSchema,
                }
                for t in tools
            ]
        return self._tools_cache

    def call(self, name: str, arguments: dict) -> str:
        return asyncio.run(self._call_tool_async(name, arguments))
