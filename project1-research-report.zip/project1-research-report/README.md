# Project 1 — Research & Report Multi-Agent Pipeline

A 4-agent pipeline (Orchestrator → Researcher → Analyst → Writer). The
Researcher is the only agent with tool access: public web search
(DuckDuckGo, no API key) and a custom MCP server exposing a local
document store. Session memory persists across runs in SQLite, and the
Researcher's static system prompt uses Anthropic prompt caching.

## File structure

```
project1-research-report/
├── orchestrator.py       # LangGraph wiring: Orchestrator → Researcher → Analyst → Writer
├── agents.py              # Agent prompts, tool-use loop, prompt caching
├── mcp_server.py           # MCP server exposing search_documents
├── mcp_client.py           # Sync wrapper around the MCP SDK, spawns mcp_server.py
├── knowledge_store.py       # Local TF-IDF document store (no external DB needed)
├── web_search.py             # DuckDuckGo web search with offline fallback
├── memory.py                  # SQLite session memory, LLM-summarized
├── run_demo.py                 # CLI entry point
├── sample_docs/
│   ├── funding_notes.md
│   └── market_report_2024.md
├── tests/
│   └── test_smoke.py            # Offline tests, no API key required
├── requirements.txt
├── .env.example
└── README.md
(sessions.db is created automatically on first run)
```

## Setup on Windows

1. **Install Python 3.11+** from [python.org](https://www.python.org/downloads/) if you don't have it. During install, check "Add python.exe to PATH".

2. **Open PowerShell or Command Prompt** in this folder.

3. **Create and activate a virtual environment:**
   ```powershell
   python -m venv .venv
   .venv\Scripts\activate
   ```
   (If PowerShell blocks the activation script, run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` first, then retry.)

4. **Install dependencies:**
   ```powershell
   pip install -r requirements.txt
   ```

5. **Add your API key:**
   ```powershell
   copy .env.example .env
   ```
   Then open `.env` in Notepad and paste your key from [console.anthropic.com](https://console.anthropic.com/).

6. **Run the offline smoke tests** (checks the doc store and search work, no API key needed):
   ```powershell
   pytest tests/test_smoke.py -v
   ```

7. **Run the full pipeline** (this calls the Anthropic API — needs your key set):
   ```powershell
   python run_demo.py "What are the latest funding trends in agentic AI startups?"
   ```

8. **Ask a follow-up using the same session** (exercises memory):
   ```powershell
   python run_demo.py "How does that compare to enterprise SaaS?" --session abc123
   ```
   (use the session id printed at the end of step 7)

## Notes

- `mcp_server.py` is spawned automatically as a subprocess by `mcp_client.py` on each tool call — you don't need to run it separately.
- Web search uses DuckDuckGo and needs no API key. If your network blocks it, `web_search.py` falls back to a placeholder result so the pipeline still completes.
- Swap the model by setting `ANTHROPIC_MODEL` in `.env` (defaults to `claude-sonnet-5`).
- `sessions.db` is created in this folder on first run — delete it to reset all session memory.
