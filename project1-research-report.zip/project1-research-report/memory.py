"""
memory.py — Cross-session memory. Keeps a rolling summary per session so
follow-up questions don't restart the pipeline from zero context.
"""
import json
import os
import sqlite3

from anthropic import Anthropic
from dotenv import load_dotenv

load_dotenv()

MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5")
client = Anthropic()


class SessionMemory:
    def __init__(self, store_path: str = "sessions.db"):
        self.db = sqlite3.connect(store_path)
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS sessions "
            "(session_id TEXT PRIMARY KEY, summary TEXT, turns TEXT)"
        )
        self.db.commit()

    def load_summary(self, session_id: str) -> str:
        row = self.db.execute(
            "SELECT summary FROM sessions WHERE session_id = ?", (session_id,)
        ).fetchone()
        return row[0] if row else "No prior context."

    def save_turn(self, session_id: str, query: str, report: str) -> None:
        prior = self.load_summary(session_id)
        summary = self._resummarize(prior, query, report)
        self.db.execute(
            "INSERT INTO sessions (session_id, summary, turns) VALUES (?,?,?) "
            "ON CONFLICT(session_id) DO UPDATE SET summary=excluded.summary",
            (session_id, summary, json.dumps({"query": query})),
        )
        self.db.commit()

    def _resummarize(self, prior: str, query: str, report: str) -> str:
        resp = client.messages.create(
            model=MODEL,
            max_tokens=300,
            messages=[
                {
                    "role": "user",
                    "content": (
                        f"Prior session summary:\n{prior}\n\n"
                        f"New question: {query}\nNew report excerpt: {report[:800]}\n\n"
                        "Write an updated 3-4 sentence summary of what this "
                        "session has covered, for use as context in future turns."
                    ),
                }
            ],
        )
        return resp.content[0].text
