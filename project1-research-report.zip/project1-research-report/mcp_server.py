"""
mcp_server.py — Custom MCP server exposing a local document store as a
search_documents tool over the Model Context Protocol. Spawned
automatically by mcp_client.py — you normally don't run this file
directly.

To run it standalone for debugging:
    python mcp_server.py
"""
import asyncio
import json

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from knowledge_store import DocumentStore

store = DocumentStore(collection="client_knowledge_base")
server = Server("research-knowledge-mcp")


@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="search_documents",
            description=(
                "Search the local knowledge base (market reports, funding "
                "notes) for passages relevant to a query. Returns ranked "
                "snippets with source metadata."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string"},
                    "top_k": {"type": "integer", "default": 5},
                },
                "required": ["query"],
            },
        )
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    if name != "search_documents":
        raise ValueError(f"Unknown tool: {name}")

    results = store.similarity_search(
        arguments["query"], k=arguments.get("top_k", 5)
    )
    payload = [
        {"source": r.source, "score": round(r.score, 3), "text": r.text}
        for r in results
    ]
    return [TextContent(type="text", text=json.dumps(payload, indent=2))]


async def _main():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


if __name__ == "__main__":
    asyncio.run(_main())
