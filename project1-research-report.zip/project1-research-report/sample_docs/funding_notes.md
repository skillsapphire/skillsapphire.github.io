## Agentic AI Startup Funding — Internal Notes (2024)

Seed rounds for agentic AI startups averaged roughly 40% larger than
comparable enterprise SaaS seed rounds in 2024, driven by investor
appetite for teams with a working agent demo rather than a slide deck.

Series A rounds showed more caution: investors increasingly asked for
evidence of retention and usage depth, not just novelty, before writing
larger checks.

A handful of late-2024 deals closed at markdowns compared to their prior
rounds, concentrated among startups that had not moved past a chat-based
demo into a production-grade agent with real customers.

## Enterprise SaaS Funding Baseline (2024)

Enterprise SaaS funding in 2024 remained comparatively steady, with deal
volume holding close to 2023 levels even as average deal size dipped
slightly. Investors favored SaaS companies with clear expansion revenue
and predictable renewal rates over pure new-logo growth.
