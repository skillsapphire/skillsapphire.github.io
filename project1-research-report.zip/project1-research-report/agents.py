"""
agents.py — Researcher, Analyst, and Writer agents. Researcher is the
only agent with tool access (web search + the MCP knowledge base tool);
Analyst and Writer are plain completion calls over the Researcher's
findings.
"""
import json
import os

from anthropic import Anthropic
from dotenv import load_dotenv

from mcp_client import MCPToolClient
from web_search import run_web_search

load_dotenv()

MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5")

client = Anthropic()
mcp = MCPToolClient(server_command=["python", "mcp_server.py"])

RESEARCHER_SYSTEM = """You are the Researcher agent in a multi-agent research \
pipeline. Given a sub-question, decide whether to search the web, the \
internal knowledge base (via the search_documents tool), or both. Always \
cite sources by name. Keep your final answer to 2-4 sentences."""

WEB_SEARCH_TOOL = {
    "name": "web_search",
    "description": "Search the public web for recent, dated information.",
    "input_schema": {
        "type": "object",
        "properties": {"query": {"type": "string"}},
        "required": ["query"],
    },
}


def _researcher_system_blocks(memory_summary: str) -> list[dict]:
    return [
        {
            "type": "text",
            "text": RESEARCHER_SYSTEM,
            "cache_control": {"type": "ephemeral"},
        },
        {"type": "text", "text": f"Session memory:\n{memory_summary}"},
    ]


def researcher_turn(sub_question: str, memory_summary: str) -> str:
    tools = [WEB_SEARCH_TOOL, *mcp.as_anthropic_tools()]
    messages = [{"role": "user", "content": sub_question}]

    response = client.messages.create(
        model=MODEL,
        max_tokens=800,
        system=_researcher_system_blocks(memory_summary),
        tools=tools,
        messages=messages,
    )

    # Tool-use loop — a couple of rounds is plenty for this demo.
    for _ in range(3):
        tool_uses = [b for b in response.content if b.type == "tool_use"]
        if not tool_uses:
            break

        messages.append({"role": "assistant", "content": response.content})
        tool_results = []
        for block in tool_uses:
            if block.name == "web_search":
                result = run_web_search(block.input["query"])
            else:
                result = mcp.call(block.name, block.input)
            content_str = result if isinstance(result, str) else json.dumps(result)
            tool_results.append(
                {"type": "tool_result", "tool_use_id": block.id, "content": content_str}
            )
        messages.append({"role": "user", "content": tool_results})

        response = client.messages.create(
            model=MODEL,
            max_tokens=800,
            system=_researcher_system_blocks(memory_summary),
            tools=tools,
            messages=messages,
        )

    return "\n".join(b.text for b in response.content if b.type == "text")


def plan_subtasks(query: str, memory_summary: str) -> list[str]:
    response = client.messages.create(
        model=MODEL,
        max_tokens=300,
        messages=[
            {
                "role": "user",
                "content": (
                    f"Session memory:\n{memory_summary}\n\n"
                    f"Break this research question into 2-3 concrete "
                    f"sub-questions, one per line, no numbering:\n{query}"
                ),
            }
        ],
    )
    text = response.content[0].text
    return [line.strip("-• ") for line in text.strip().split("\n") if line.strip()]


def analyst_turn(findings: list[str]) -> str:
    joined = "\n\n".join(f"Finding {i + 1}: {f}" for i, f in enumerate(findings))
    response = client.messages.create(
        model=MODEL,
        max_tokens=500,
        messages=[
            {
                "role": "user",
                "content": f"Synthesize these research findings and flag any contradictions:\n\n{joined}",
            }
        ],
    )
    return response.content[0].text


def writer_turn(analysis: str, original_query: str) -> str:
    response = client.messages.create(
        model=MODEL,
        max_tokens=600,
        messages=[
            {
                "role": "user",
                "content": (
                    f"Original question: {original_query}\n\nAnalysis:\n{analysis}\n\n"
                    "Write a short cited report (3-5 sentences) answering the "
                    "original question."
                ),
            }
        ],
    )
    return response.content[0].text
