"""
knowledge_store.py — Minimal local document store used by mcp_server.py.

Uses TF-IDF over the markdown files in sample_docs/ instead of a full
vector database, so the demo runs with no external services. Only the
LLM calls (in agents.py) need ANTHROPIC_API_KEY — retrieval itself works
fully offline.
"""
import glob
import os
from dataclasses import dataclass

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


@dataclass
class SearchResult:
    text: str
    source: str
    score: float


class DocumentStore:
    def __init__(self, collection: str, docs_glob: str = None):
        self.collection = collection
        base_dir = os.path.dirname(os.path.abspath(__file__))
        self.docs_glob = docs_glob or os.path.join(base_dir, "sample_docs", "*.md")

        self._sources: list[str] = []
        self._texts: list[str] = []

        for path in sorted(glob.glob(self.docs_glob)):
            with open(path, encoding="utf-8") as f:
                content = f.read()
            for para in [p.strip() for p in content.split("\n\n") if p.strip()]:
                self._texts.append(para)
                self._sources.append(os.path.basename(path))

        self._vectorizer = None
        self._matrix = None
        if self._texts:
            self._vectorizer = TfidfVectorizer(stop_words="english")
            self._matrix = self._vectorizer.fit_transform(self._texts)

    def similarity_search(self, query: str, k: int = 5) -> list[SearchResult]:
        if not self._texts:
            return []
        query_vec = self._vectorizer.transform([query])
        scores = cosine_similarity(query_vec, self._matrix)[0]
        ranked = sorted(zip(self._texts, self._sources, scores), key=lambda x: -x[2])
        return [
            SearchResult(text=t, source=s, score=float(sc))
            for t, s, sc in ranked[:k]
            if sc > 0
        ]


if __name__ == "__main__":
    store = DocumentStore(collection="demo")
    for r in store.similarity_search("funding trends", k=3):
        print(f"[{r.score:.3f}] {r.source}: {r.text[:80]}...")
