"""
tests/test_smoke.py — Offline sanity checks that don't require an
Anthropic API key. Run: pytest tests/test_smoke.py -v
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from knowledge_store import DocumentStore  # noqa: E402
from web_search import run_web_search  # noqa: E402


def test_document_store_finds_relevant_chunk():
    store = DocumentStore(collection="test")
    results = store.similarity_search("funding trends agentic AI", k=3)
    assert len(results) > 0
    assert any("fund" in r.text.lower() for r in results)


def test_document_store_empty_query_is_safe():
    store = DocumentStore(collection="test")
    results = store.similarity_search("zzz_no_match_zzz", k=3)
    assert isinstance(results, list)


def test_web_search_never_raises():
    # Should return a real or fallback result either way, never throw.
    results = run_web_search("agentic AI funding 2024")
    assert isinstance(results, list)
    assert len(results) >= 1
