"""
run_demo.py — CLI entry point.

Usage:
    python run_demo.py "your research question here"
    python run_demo.py "your research question here" --session my-session
"""
import sys
import uuid

from orchestrator import run

if __name__ == "__main__":
    args = sys.argv[1:]
    session_id = str(uuid.uuid4())[:8]
    if "--session" in args:
        idx = args.index("--session")
        session_id = args[idx + 1]
        args = args[:idx] + args[idx + 2 :]

    query = " ".join(args) or (
        "What are the latest funding trends in agentic AI startups, and how "
        "do they compare to enterprise SaaS funding?"
    )

    print(f"\nSession: {session_id}")
    print(f"Query:   {query}\n")
    print("Running pipeline (this calls the Anthropic API and may take 20-60s)...\n")

    report = run(query, session_id)

    print("=== FINAL REPORT ===\n")
    print(report)
    print(f"\n(Session memory saved under id '{session_id}' — reuse --session "
          f"{session_id} to ask a follow-up with context.)")
