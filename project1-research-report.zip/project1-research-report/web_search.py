"""
web_search.py — Real web search via DuckDuckGo (no API key required),
with a graceful offline fallback so the pipeline still runs if the
network or the search package is unavailable.
"""


def run_web_search(query: str, max_results: int = 5) -> list[dict]:
    try:
        from ddgs import DDGS

        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=max_results))
        if not results:
            raise ValueError("no results returned")
        return [
            {
                "title": r.get("title", ""),
                "url": r.get("href", ""),
                "snippet": r.get("body", ""),
            }
            for r in results
        ]
    except Exception as e:
        return [
            {
                "title": "Web search unavailable (offline fallback)",
                "url": "",
                "snippet": (
                    f"Could not reach web search ({e}). This is a placeholder "
                    f"result so the pipeline can still run end to end offline."
                ),
            }
        ]
